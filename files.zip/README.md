# Portefølje-nettsted — kom i gang

Dette er en enkel, ren HTML/CSS/JS-nettside. Ingen rammeverk, ingen bygge-steg —
du kan redigere filene direkte og laste dem opp hvor som helst.

## Filstruktur

```
index.html                     ← forsiden (bilde, "meet the designer", mapper)
prosjekt-eventapp.html         ← prosjektside 1
prosjekt-hotell.html           ← prosjektside 2
prosjekt-brukertesting.html    ← prosjektside 3
cv.html                        ← CV-siden
style.css                      ← all styling (farger, fonter, layout)
script.js                      ← mappe-interaksjonen
assets/                        ← legg bilder og CV-PDF her
```

## 1. Bytt ut placeholder-innhold

Søk gjennom filene etter tekst i klammeparenteser, f.eks. `[Ditt Navn]`,
`[din@epost.no]`, `[Beskriv problemet...]` — dette er steder du skal fylle
inn ditt eget innhold. De fleste kodeeditorer (VS Code, Cursor) har
"Search across files" (Ctrl/Cmd+Shift+F) slik at du kan bytte ut
`[Ditt Navn]` med ditt eget navn i alle filer på én gang.

## 2. Legg til bilder

1. Legg bildene dine i `assets/`-mappen (f.eks. `meg-fullengde.jpg`,
   `meg-portrett.jpg`).
2. I `index.html` finner du to steder merket `photo-placeholder` —
   fjern/erstatt disse med en `<img>`-tag. Det står allerede en
   ferdig kommentert linje rett under hver placeholder du kan bruke,
   f.eks.:
   ```html
   <img src="assets/meg-fullengde.jpg" alt="[Ditt navn]">
   ```
3. Gjør det samme i prosjektsidene for skjermbilder/mockups
   (`.image-placeholder`-boksene).

## 3. Legg til CV som PDF

Legg PDF-filen din i `assets/` og kall den `cv-ditt-navn.pdf` (eller endre
lenken i `cv.html` til å matche filnavnet ditt).

## 4. Publiser gratis

Du trenger ikke betale for hosting til dette. To enkle, gratis alternativ:

### Alternativ A: Netlify Drop (raskest, ingen konto nødvendig for å teste)
1. Gå til https://app.netlify.com/drop
2. Dra hele `portfolio`-mappen inn i nettleservinduet.
3. Du får en lenke med en gang (f.eks. `dittnavn.netlify.app`).
4. Opprett gratis konto for å kunne oppdatere siden senere og evt. koble på
   eget domene.

### Alternativ B: GitHub Pages (bra hvis du uansett vil vise frem koden din på GitHub — fint for en IT-student!)
1. Lag et nytt repo på GitHub, f.eks. `portfolio`.
2. Last opp alle filene i denne mappen til repoet.
3. Gå til repoets **Settings → Pages**.
4. Under "Source", velg branch `main` og mappe `/ (root)`.
5. Etter et minutt får du en lenke som `dittbrukernavn.github.io/portfolio`.

Begge disse er 100 % gratis og perfekte å sende til fremtidige
arbeidsgivere.

## 5. Egen domene (valgfritt)

Både Netlify og GitHub Pages støtter å koble på et eget domene
(f.eks. `dittnavn.no`) senere, hvis du ønsker det — dette koster kun det
domenet selv (typisk 100–200 kr/år), selve hostingen er fortsatt gratis.

## Tilpasse design

Alle farger og fonter styres fra toppen av `style.css` under
`:root { ... }`. Vil du f.eks. ha en annen rødfarge på mappene,
bytt verdien på `--brick`.
